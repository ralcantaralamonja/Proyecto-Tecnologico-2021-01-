3D Icons v2.0 Preview
by Albert Kan
Email: syk108@psu.edu
Homepage: http://www.personal.psu.edu
Date: 1/12/97

This is the preview of v2.0. The zip file does not contain
an install program, but only icons.

First, extract the zip file to a folder. Second, copy all
the icons to C:\Program Files\Shell Icons

To install FILE TYPES icons, use Explorer/View/Option/File Types.
Select the type of file you want to change, then click Edit.
Choose Change Icon.

If you know how to edit .REG file, you can use the new system icons.
(Remember that it is \\, not \). If you don't know how, hang on.
A new .REG for system icons will be posted later.